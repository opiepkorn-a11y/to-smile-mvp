# main.py

print('Hello To Smile MVP')
